author = "EHB Dev Team";
name = "Echo Hand Battalion Aux Mod";
description = "Echo Hand Battalion Aux Mod - Version 1.3.0";
overview = "Auxiliary content for the Echo Hand Battalion. Includes units, vehicles, and loadouts.";
overviewPicture = "EHB.paa";
picture = "EHB.png";
logo = "EHB.paa";
logoOver = "EHB.paa";
