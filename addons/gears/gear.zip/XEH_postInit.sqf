#include "script_component.hpp"

if (!hasInterface) exitWith {};

[] spawn {
    waitUntil { !isNull player };

    private _maskClass = QCLASS(Balaclava_OPTREHUD);   // your goggles-slot mask class
    private _hudClass  = "OPTRE_HUD_In_Glasses";          // OPTRE HUD glasses

    player setVariable ["ehb_prevGoggles", goggles player];
    player setVariable ["ehb_hudActive", false];

    addMissionEventHandler ["EachFrame", {

        private _maskOn = (goggles player) isEqualTo _maskClass;
        private _active = player getVariable ["ehb_hudActive", false];

        // Mask equipped -> apply OPTRE HUD glasses
        if (_maskOn && !_active) then {
            player setVariable ["ehb_prevGoggles", _maskClass]; // store mask as "prev" so we can restore it
            removeGoggles player;
            player addGoggles _hudClass;

            player setVariable ["ehb_hudActive", true];
        };

        // If HUD glasses are on but mask is not meant to be active anymore, restore
        if (!_maskOn && _active) then {
            // If the player changed goggles manually, do not fight them.
            // Only restore if we are still wearing the HUD glasses we applied.
            if ((goggles player) isEqualTo _hudClass) then {
                removeGoggles player;

                // restore the original mask goggles
                private _restore = player getVariable ["ehb_prevGoggles", ""];
                if (_restore != "" && _restore != "None") then {
                    player addGoggles _restore;
                };
            };

            player setVariable ["ehb_hudActive", false];
        };
    }];
};
