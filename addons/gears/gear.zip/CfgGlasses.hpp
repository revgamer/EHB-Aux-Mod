class CfgGlasses
{
    class OPTRE_HUD_In_Glasses;

    class CLASS(Balaclava_OPTREHUD) : OPTRE_HUD_In_Glasses
    {
        SCOPE_PUBLIC;
        author = AUTHOR;

        displayName = "[EHB] Stealth Balaclava (TI) + OPTRE HUD";

        // Use the vanilla TI balaclava goggles model (so it physically looks correct)
        model = "\A3\Characters_F_Exp\BLUFOR\G_Balaclava_TI_G_F.p3d";

        hiddenSelections[] = {"camo1","camo2"};
        hiddenSelectionsTextures[] =
        {
            "\A3\Characters_F_Exp\BLUFOR\Data\G_Balaclava_TI_blk_F_co.paa",
            "\A3\Characters_F\Heads\Glasses\data\g_combat_ca.paa"
        };

        mass = 10;
        identityTypes[] = {};

        // Keep OPTRE HUD config from parent (these exist on OPTRE_HUD_In_Glasses)
        optreHUDStyle = "Glasses";
        // optreVariety[] inherited; override only if you know the exact keys you want
        // optreVariety[] = {"","",""};

        // Copy the ACE “goggles HUD/dust” behaviour from the vanilla TI balaclava goggles
        ACE_Color[]          = {0,0,0};
        ACE_DustPath         = "\z\ace\addons\goggles\textures\fx\dust\%1.paa";
        ACE_Overlay          = "\z\ace\addons\goggles\textures\HUD\CombatGoggles.paa";
        ACE_OverlayCracked   = "\z\ace\addons\goggles\textures\HUD\CombatGogglesCracked.paa";
        ACE_OverlayDirt      = "A3\Ui_f\data\igui\rsctitles\HealthTextures\dust_upper_ca.paa";
        ACE_Protection       = 1;
        ACE_Resistance       = 2;
        ACE_TintAmount       = 0;
    };
};
